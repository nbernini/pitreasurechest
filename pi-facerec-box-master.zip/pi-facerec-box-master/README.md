Raspberry Pi Face Recognition Treasure Box
==========================================

Raspberry Pi powered box which uses face recognition with OpenCV to lock and unlock itself.  See the tutorial [on the Adafruit learning system](http://learn.adafruit.com/raspberry-pi-face-recognition-treasure-box/overview).
